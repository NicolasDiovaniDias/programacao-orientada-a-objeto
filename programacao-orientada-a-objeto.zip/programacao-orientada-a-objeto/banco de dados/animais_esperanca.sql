-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Dez-2024 às 14:04
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `animais_esperanca`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `abrigos`
--

CREATE TABLE `abrigos` (
  `id_abrigos` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `capacidade` int(5) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `abrigos`
--

INSERT INTO `abrigos` (`id_abrigos`, `nome`, `endereco`, `capacidade`, `data`) VALUES
(1, 'eldorado', 'av nestor jardim filho', 5, '2024-12-12 10:30:57'),
(2, 'porto alegre', 'av navegantes', 10, '2024-12-12 12:25:27'),
(3, 'cachoeirinha', 'fabio av bla bla bla', 4, '2024-12-12 13:04:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `animais`
--

CREATE TABLE `animais` (
  `id_animais` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `raca` varchar(50) NOT NULL,
  `especie` varchar(50) NOT NULL,
  `genero` char(1) NOT NULL,
  `idade` varchar(3) NOT NULL,
  `localResgatado` varchar(50) NOT NULL,
  `resgatador` varchar(50) NOT NULL,
  `abrigo` int(11) DEFAULT NULL,
  `situacao` char(1) NOT NULL DEFAULT 'A',
  `data` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_pessoas` int(11) DEFAULT NULL,
  `fk_tutores` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `animais`
--

INSERT INTO `animais` (`id_animais`, `nome`, `raca`, `especie`, `genero`, `idade`, `localResgatado`, `resgatador`, `abrigo`, `situacao`, `data`, `fk_pessoas`, `fk_tutores`) VALUES
(6, 'arnaldo', 'siames', 'gato', 'M', '3', 'eldorado', 'eu', 1, 'A', '2024-12-12 12:38:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `animais_adotados`
--

CREATE TABLE `animais_adotados` (
  `id_adotados` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `idade` varchar(3) NOT NULL,
  `especie` varchar(50) NOT NULL,
  `raca` varchar(50) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_pessoas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `animais_adotados`
--

INSERT INTO `animais_adotados` (`id_adotados`, `nome`, `idade`, `especie`, `raca`, `data`, `fk_pessoas`) VALUES
(2, 'arnaldo', '4', 'gato', 'siames', '2024-12-12 12:32:31', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `caes`
--

CREATE TABLE `caes` (
  `id_caes` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `raca` varchar(50) NOT NULL,
  `especie` varchar(50) NOT NULL,
  `genero` char(1) NOT NULL,
  `idade` varchar(3) NOT NULL,
  `localResgatado` varchar(100) NOT NULL,
  `resgatador` varchar(100) NOT NULL,
  `abrigo` int(11) DEFAULT NULL,
  `porte` char(1) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `caracteristicas` varchar(100) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_animais` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gatos`
--

CREATE TABLE `gatos` (
  `id_gatos` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `raca` varchar(50) NOT NULL,
  `especie` varchar(50) NOT NULL,
  `genero` char(1) NOT NULL,
  `idade` varchar(3) NOT NULL,
  `localResgatado` varchar(100) NOT NULL,
  `resgatador` varchar(100) NOT NULL,
  `abrigo` int(11) DEFAULT NULL,
  `cor` varchar(50) NOT NULL,
  `caracteristicas` varchar(100) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_animais` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `gatos`
--

INSERT INTO `gatos` (`id_gatos`, `nome`, `raca`, `especie`, `genero`, `idade`, `localResgatado`, `resgatador`, `abrigo`, `cor`, `caracteristicas`, `data`, `fk_animais`) VALUES
(3, 'arnaldo', 'siames', 'gato', 'M', '3', 'eldorado', 'eu', 1, 'cinza', 'lindo', '2024-12-12 12:38:40', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `historico`
--

CREATE TABLE `historico` (
  `id_historico` int(11) NOT NULL,
  `historico` varchar(200) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `historico`
--

INSERT INTO `historico` (`id_historico`, `historico`, `data`) VALUES
(1, 'o animal nicolas do id: 3 foi inserido', '2024-12-12 10:31:17'),
(2, 'o animal arnaldo do id: 4 foi inserido', '2024-12-12 12:24:04'),
(3, 'o animal gatao do id: 5 foi inserido', '2024-12-12 12:26:01'),
(4, 'a pessoa nicolas(1) foi inserida', '2024-12-12 12:27:03'),
(5, 'o animal arnaldo (4) foi adotado por 0 (1)', '2024-12-12 12:32:31'),
(6, 'a pessoa nicolas(2) foi inserida', '2024-12-12 12:34:13'),
(7, 'a pessoa nicolas(3) foi inserida', '2024-12-12 12:37:06'),
(8, 'o animal arnaldo do id: 6 foi inserido', '2024-12-12 12:38:33'),
(9, 'o tutor nicola(12) foi inserido', '2024-12-12 12:40:03'),
(10, 'o animal arnaldo (6) foi tutelado por nicola (12)', '2024-12-12 12:40:13'),
(11, 'o animal arnaldo (6) foi destutelado por nicola (12)', '2024-12-12 12:41:00'),
(12, 'o tutor pedro livi(13) foi inserido', '2024-12-12 12:56:35'),
(13, 'o tutor nicolas(14) foi inserido', '2024-12-12 12:57:56'),
(14, 'a pessoa pedro(4) foi inserida', '2024-12-12 13:00:18');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE `pessoas` (
  `id_pessoas` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `pessoas`
--

INSERT INTO `pessoas` (`id_pessoas`, `nome`, `telefone`, `cpf`, `email`, `senha`, `data`) VALUES
(1, '0', '984109830', '02363124057', 'nicolas@gmail.com', '1234', '2024-12-12 12:27:02'),
(2, '0', '984109830', '02363124057', 'nicolas@gmail.com', '1234', '2024-12-12 12:34:13'),
(3, 'nicolas', '984109830', '02363124057', 'nicolas@gmail.com', '123', '2024-12-12 12:37:06'),
(4, 'pedro', '2342346365', '2334563453', 'pedro@gmail.com', 'livi', '2024-12-12 13:00:18');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tutores`
--

CREATE TABLE `tutores` (
  `id_tutores` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tutores`
--

INSERT INTO `tutores` (`id_tutores`, `nome`, `telefone`, `endereco`, `email`, `senha`, `data`) VALUES
(12, 'nicola', '984109830', 'av nestor jardim filho', 'nicolas@gmail.com', '123', '2024-12-12 12:40:03'),
(13, 'pedro livi', '2343423423', 'poa rs', 'livi@gmail.com', 'livi', '2024-12-12 12:56:35'),
(14, 'nicolas', '6345345', 'poa rs', 'diovani@gmail.com', '123', '2024-12-12 12:57:56');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `abrigos`
--
ALTER TABLE `abrigos`
  ADD PRIMARY KEY (`id_abrigos`);

--
-- Índices para tabela `animais`
--
ALTER TABLE `animais`
  ADD PRIMARY KEY (`id_animais`),
  ADD KEY `fk_tutores` (`fk_tutores`),
  ADD KEY `abrigo` (`abrigo`),
  ADD KEY `fk_pessoas` (`fk_pessoas`);

--
-- Índices para tabela `animais_adotados`
--
ALTER TABLE `animais_adotados`
  ADD PRIMARY KEY (`id_adotados`),
  ADD KEY `fk_pessoas` (`fk_pessoas`);

--
-- Índices para tabela `caes`
--
ALTER TABLE `caes`
  ADD PRIMARY KEY (`id_caes`),
  ADD KEY `fk_animais` (`fk_animais`),
  ADD KEY `abrigo` (`abrigo`);

--
-- Índices para tabela `gatos`
--
ALTER TABLE `gatos`
  ADD PRIMARY KEY (`id_gatos`),
  ADD KEY `abrigo` (`abrigo`),
  ADD KEY `fk_animais` (`fk_animais`);

--
-- Índices para tabela `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`id_historico`);

--
-- Índices para tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`id_pessoas`);

--
-- Índices para tabela `tutores`
--
ALTER TABLE `tutores`
  ADD PRIMARY KEY (`id_tutores`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `abrigos`
--
ALTER TABLE `abrigos`
  MODIFY `id_abrigos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `animais`
--
ALTER TABLE `animais`
  MODIFY `id_animais` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `animais_adotados`
--
ALTER TABLE `animais_adotados`
  MODIFY `id_adotados` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `caes`
--
ALTER TABLE `caes`
  MODIFY `id_caes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `gatos`
--
ALTER TABLE `gatos`
  MODIFY `id_gatos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `historico`
--
ALTER TABLE `historico`
  MODIFY `id_historico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `id_pessoas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tutores`
--
ALTER TABLE `tutores`
  MODIFY `id_tutores` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `animais`
--
ALTER TABLE `animais`
  ADD CONSTRAINT `animais_ibfk_1` FOREIGN KEY (`abrigo`) REFERENCES `abrigos` (`id_abrigos`),
  ADD CONSTRAINT `animais_ibfk_2` FOREIGN KEY (`fk_pessoas`) REFERENCES `pessoas` (`id_pessoas`),
  ADD CONSTRAINT `fk_tutores` FOREIGN KEY (`fk_tutores`) REFERENCES `tutores` (`id_tutores`);

--
-- Limitadores para a tabela `animais_adotados`
--
ALTER TABLE `animais_adotados`
  ADD CONSTRAINT `animais_adotados_ibfk_1` FOREIGN KEY (`fk_pessoas`) REFERENCES `pessoas` (`id_pessoas`);

--
-- Limitadores para a tabela `caes`
--
ALTER TABLE `caes`
  ADD CONSTRAINT `caes_ibfk_1` FOREIGN KEY (`fk_animais`) REFERENCES `animais` (`id_animais`),
  ADD CONSTRAINT `caes_ibfk_2` FOREIGN KEY (`abrigo`) REFERENCES `abrigos` (`id_abrigos`);

--
-- Limitadores para a tabela `gatos`
--
ALTER TABLE `gatos`
  ADD CONSTRAINT `gatos_ibfk_1` FOREIGN KEY (`abrigo`) REFERENCES `abrigos` (`id_abrigos`),
  ADD CONSTRAINT `gatos_ibfk_2` FOREIGN KEY (`fk_animais`) REFERENCES `animais` (`id_animais`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
