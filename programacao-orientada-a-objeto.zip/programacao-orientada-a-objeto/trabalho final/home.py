import abrigos
import animais
import pessoa
import tutor
while True:
    escolha = input(f"qual voce quer fazer?\n0)nada\n1)adicionar animal\n2)buscar animal\n3)registrar pessoa\n4)adotar animal\n5)adicionar abrigo\n:")
    if escolha == "1":
        animais.enviar_banco()
    elif escolha == "2":
        animais.toString()
    elif escolha == "3":
        pessoa.registrar_pessoa()
    elif escolha == "4":
        pessoa.adotar_animal()
    elif escolha == "5":
        abrigos.adicionarAbrigo()
    elif escolha == "0":
        break
